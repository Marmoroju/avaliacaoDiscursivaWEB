<?php
    include('protect.php');
    include_once('conexao.php');
    
        
    if(isset($_POST["submit"])) {
        $nome= $_POST["nome"];
        $endereco= $_POST["endereco"];
        $cidade= $_POST["cidade"];
        $lojas= $_POST["lojas"]; 
        
        $sql = "INSERT INTO cad_estab (nome, endereco, cidade, lojas) 
        VALUES ('$nome', '$endereco', '$cidade', $lojas)";
           
        if(mysqli_query($conexao, $sql)) {
            echo "Estabelecimento cadastrado com sucesso";
        }
        else {
            echo "Erro ao cadastrar o Estabelecimento".mysqli_connect_error($conexao);
        }
        mysqli_close($conexao);
    }
        

?>


