<?php

include('protect.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="reset.css"> <link rel="stylesheet" type="text/css" href="estilo.css">
    <title>Painel</title>  

</head>
<body>
    <h1>Bem-vindo ao Menu, <?php echo $_SESSION['nome']; ?>.</h1>
    <p></p>
    <h3>Agora escolha uma das opções abaixo:</h3>
    <p></p>
    
    <div>
        <a href="produtos.php">Cadastrar Produtos</a>
        <p></p>
        <a href="preco.php">Cadastro de Valores</a>
        <p></p>
        <a href="estabelecimento.php">Cadastrar Estabelecimento</a>
        <p></p>
        <a href="barato.php">Produto mais barato</a>
    </div>
    
    <div>
        <a href="logout.php">Sair</a>
    </div>        
</body>
</html>