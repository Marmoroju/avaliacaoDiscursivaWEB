<?php

include('protect.php');
include_once('conexao.php');

if(isset($_POST["submit"])) {    
    $produto= $_POST['produto'];
           
    $sql = "SELECT * FROM cad_preco 
            WHERE estab_id =  $produto ORDER BY valor ASC";

    if(mysqli_query($conexao, $sql)) {
        $mensagem = "O produto está mais barato no estabelecimento: .";
    }
    else {
        echo "Erro encontrar a loja".mysqli_connect_error($conexao);
    }
    mysqli_close($conexao);
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="reset.css"> <link rel="stylesheet" type="text/css" href="estilo.css">
    <title>Mais barato!</title>
</head>
<body>
    <h1>Procure pelo produto mais barato!</h1>
<form method="POST" action="barato.php">
        <!-- Combobox para selecionar o Produto -->
        <label>Produto</label>
        <select name="produto">
            <?php
                $conn = mysqli_connect("localhost", "root", "", "login");
                if ($conn) {
                    $sql = "SELECT * FROM cad_produto";
                    $result = mysqli_query($conn, $sql);
                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $id = $row['id'];
                            $nome = $row['nome'];
                            echo "<option value='$id'>$nome</option>";
                            
                        }
                    }
                }
            ?>        
        </select>
        <label></label>
        <select hidden name="estabelecimento">
            <?php
                
                $conn = mysqli_connect("localhost", "root", "", "login");
                if ($conn) {
                    $sql = "SELECT * FROM cad_estab";
                    $result = mysqli_query($conn, $sql);
                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            
                            $id = $row['id'];
                            $nome = $row['nome'];
                            
                            echo "<option value='$id'>$nome</option>";
                            
                        }
                    }
                }
            ?>
        </select>   
        <p>
        <button type="submit" name="submit">Confirmar</button>
        </p> 
</form> 
<br>
<form>
    <label>Resultado:</label>
        <textarea id="mensagem" name="mensagem"><?php echo $mensagem; ?></textarea><br><br>
    </form>   
    <div>
        <a href="menu.php">Sair</a>
    </div>
</body>
</html>