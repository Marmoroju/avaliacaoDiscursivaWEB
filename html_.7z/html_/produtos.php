<?php
include('protect.php');
include_once('conexao.php');
include('cadastro_produto.php');
  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="reset.css"> <link rel="stylesheet" type="text/css" href="estilo.css">
    <title>Cadastro de Produtos</title>
    
</head>
<body>
    <h1>Cadastro de Produtos</h1>

    <form method="POST" action="produtos.php">
        <label>Nome</label><input type="text" name="nome"><br>
        <label>Marca</label><input type="text" name="marca"><br>
        <label>Medida</label><input type="text" name="medida"><br>
        <label>Quantidade</label><input type="text" name="quantidade"><br>
        <button type="submit" name="submit">Cadastrar</button>         
    </form>

    <div>
        <a href="menu.php">Sair</a>
    </div>
</body>
</html>
