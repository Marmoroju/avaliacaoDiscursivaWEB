<?php
    include('protect.php');
    include_once('conexao.php');
    
        
    if(isset($_POST["submit"])) {
        $nome= $_POST["nome"];
        $marca= $_POST["marca"];
        $medida= $_POST["medida"];
        $quantidade= $_POST["quantidade"]; 
        
        $sql = "INSERT INTO cad_produto (nome, marca, medida, quantidade) 
        VALUES ('$nome', '$marca', '$medida', $quantidade)";
           
        if(mysqli_query($conexao, $sql)) {
            echo "Produto cadastrado com sucesso";
        }
        else {
            echo "Erro ao cadastrar o produto".mysqli_connect_error($conexao);
        }
        mysqli_close($conexao);
    }
        

?>


