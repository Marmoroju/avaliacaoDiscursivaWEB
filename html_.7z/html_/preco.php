<?php
include('protect.php');
include_once('conexao.php');

if(isset($_POST["submit"])) {
    
    $produto= $_POST['produto'];
    $estabelecimento = $_POST['estabelecimento'];
    $valor= $_POST['valor'];
        
    $sql = "INSERT INTO cad_preco (id, produto_id, estab_id, valor) 
    VALUES ('', $produto, $estabelecimento, $valor)";
       
    if(mysqli_query($conexao, $sql)) {
        echo "Produto cadastrado com sucesso";
    }
    else {
        echo "Erro ao cadastrar o produto".mysqli_connect_error($conexao);
    }
    mysqli_close($conexao);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="reset.css"> <link rel="stylesheet" type="text/css" href="estilo.css">
    <title>Cadastro de Valores</title>
    
</head>
<body>
    <h1>Cadastro de Valores</h1>

    <form method="POST" action="preco.php">
        <!-- Combobox para selecionar o Produto -->
        <label>Produto</label>
        <select name="produto">
            <?php
                $conn = mysqli_connect("localhost", "root", "", "login");
                if ($conn) {
                    $sql = "SELECT * FROM cad_produto";
                    $result = mysqli_query($conn, $sql);
                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $id = $row['id'];
                            $nome = $row['nome'];
                            echo "<option value='$id'>$nome</option>";
                            
                        }
                    }
                }
            ?>
        </select>
        <br>
        <!-- Combobox para selecionar o estabelecimento -->
        <label>Estabelecimento</label>
        <select name="estabelecimento">
            <?php
                
                $conn = mysqli_connect("localhost", "root", "", "login");
                if ($conn) {
                    $sql = "SELECT * FROM cad_estab";
                    $result = mysqli_query($conn, $sql);
                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            
                            $id = $row['id'];
                            $nome = $row['nome'];
                            
                            echo "<option value='$id'>$nome</option>";
                            
                        }
                    }
                }
            ?>
        </select>
        <br>
        
        <label>Valor</label><input type="text" name="valor"><br>
        <button type="submit" name="submit">Cadastrar</button>         
    </form>

    <div>
        <a href="menu.php">Sair</a>
    </div>
</body>
</html>
