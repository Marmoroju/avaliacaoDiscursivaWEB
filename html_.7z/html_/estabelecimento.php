<?php

include('protect.php');
include_once('conexao.php');
include('cadastro_estabelecimento.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="reset.css"> <link rel="stylesheet" type="text/css" href="estilo.css">
    <title>Cadastro de Estabelecimentos</title>
</head>
<body>
    <h1>Cadastro de Estabelecimentos</h1>
    <form method="POST" action="estabelecimento.php">
        <label>Nome</label><input type="text" name="nome"><br>
        <label>Endereço</label><input type="text" name="endereco"><br>
        <label>Cidade</label><input type="text" name="cidade"><br>
        <label>Número de lojas</label><input type="text" name="lojas"><br>
        <button type="submit" name="submit">Cadastrar</button>         
    </form>

    <div>
        <a href="menu.php">Sair</a>
</div>
</body>